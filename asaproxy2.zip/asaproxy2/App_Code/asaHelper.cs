﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Net;
using System.Text;
using System.Configuration;
using System.Web.Script.Serialization;
using System.Web.Caching;

/// <summary>
/// Summary description for asaGisHelper
/// </summary>
public class asaHelper
{
    #region static variables
    private static readonly log4net.ILog _log = log4net.LogManager.GetLogger("agsProxy");
    private static readonly string publishMode = ConfigurationManager.AppSettings["publishMode"];
    private static readonly string urlPortalRoot = ConfigurationManager.AppSettings["urlPortalRoot"];
    private static readonly string urlSampleWebMapJSON = ConfigurationManager.AppSettings["urlSampleWebMapJSON"];
    private static readonly string scenarioIDExpression = ConfigurationManager.AppSettings["scenarioIDExpression"];
    private static readonly string imgWebMapThumbnail = ConfigurationManager.AppSettings["imgWebMapThumbnail"];
    private static readonly string urlSampleMapService = ConfigurationManager.AppSettings["urlSampleMapService"];
    private static readonly string urlAGOProxyMapService = ConfigurationManager.AppSettings["urlAGOProxyMapService"];
    private static readonly string urlOilMapFeatureService = ConfigurationManager.AppSettings["urlOilMapFeatureService"];
    private static readonly string urlAGOAddItem = String.Concat(urlPortalRoot, ConfigurationManager.AppSettings["urlAGOAddItem"]);
    private static readonly string urlAGOShareItem = String.Concat(urlPortalRoot, ConfigurationManager.AppSettings["urlAGOShareItem"]);
    private static readonly string agoTokenService = String.Concat(urlPortalRoot, ConfigurationManager.AppSettings["agoTokenService"]);
    private static readonly string agoUser = ConfigurationManager.AppSettings["agoUser"];
    private static readonly string agoPassword = ConfigurationManager.AppSettings["agoPassword"];
    private static readonly string agsTokenService = ConfigurationManager.AppSettings["agsTokenService"];
    private static readonly string agsUser = ConfigurationManager.AppSettings["agsUser"];
    private static readonly string agsPassword = ConfigurationManager.AppSettings["agsPassword"];
    #endregion

    public asaHelper()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    //insert features (layer ID, feature JSON)
    public static string InsertFeatures(string layerID, string features, string agoToken)
    {
        string token = "";
        //get fs URL from config
        if (publishMode.Equals("ago"))
        {
            if (String.IsNullOrEmpty(agoToken))
            {
                //TEST: IF NO AGOTOKEN SENT IN, CREATE ONE
                token = GetAGOToken();
                if (string.IsNullOrEmpty(token))
                {
                    throw new WebException("No AGO token available; Tried to generate token but failed.", WebExceptionStatus.TrustFailure);
                }
            }
            else
            {
                token = agoToken;
            }
        }
        else
        {
            //get ags token
            string agsToken = GetAGSToken();
            if (string.IsNullOrEmpty(agsToken))
            {
                throw new WebException("No ArcGIS Server token available", WebExceptionStatus.TrustFailure);
            }
            token = agsToken;
        }

        string responseString = "";
        string postUrl = string.Format("{0}/{1}/addFeatures?token=", urlOilMapFeatureService, layerID);
        string postData = string.Format("f=json&features={0}", features);

        //call insert features on fs
        try
        {
            responseString = DoPostForString(string.Concat(postUrl, token), postData);

            //WHILE EXPLORING BUG OF INVALID TOKENS, ASSUMING ALL ERRORS ARE TOKEN RELATED AND FOR NOW, 
            //REGENERATING TOKEN REGARDLESS OF UNDERLYING CAUSE; SEND REST BACK TO CLIENT
            if (responseString.ToLower().IndexOf("error") > -1)
            {
                _log.Error("Caught error in response: " + responseString);

                //token in cache is invalid... regenerate and store in cache
                if (publishMode.Equals("ago"))
                {
                    //use AGO admin credentials to generate new token
                    token = GenerateAGOToken();
                }
                else
                {
                    token = GenerateAGSToken();
                }
                _log.Error("Caught invalid token error; generated new token: " + token);

                //try again
                responseString = DoPostForString(string.Concat(postUrl, token), postData);
            }
        }
        catch (Exception ex)
        {
            responseString = LogExceptionReturnJSON(500, ex.Message, ex.StackTrace);
        }
        return responseString;
    }

    //search for service (org ID)

    //create service

    //create service item

    //create web map
    /*When you are done posting the features to the proxy, you will send a separate POST request to the proxy service to create the web map, passing in:
        •	scenarioID
        •	startTime (UNIX time)
        •	endTime (UNIX time)
        •	token
        •	Comma-separated list of AGO Group IDs to share the web map with
    You will receive the webmap URL as a response to that.
    */
    public static string CreateWebMap(
        string username,
        string scenarioID,
        string title,
        string startTime,
        string endTime,
        string extent,
        string tokenIn
        )
    {
        string token = tokenIn;
        if (String.IsNullOrEmpty(token))
        {
            //IF NO AGOTOKEN SENT IN, CREATE ONE
            token = GetAGOToken();
            if (string.IsNullOrEmpty(token))
            {
                throw new WebException("No AGO token available; Tried to generate token but failed.", WebExceptionStatus.TrustFailure);
            }
        }
        string urlAGOAddItemUser = string.Format(urlAGOAddItem, username);

        string sampleWebMapJSON = DoPostForString(urlSampleWebMapJSON, "");

        if (sampleWebMapJSON.ToLower().Contains("\"error\":"))
        {
            return sampleWebMapJSON;
        }

        //BUG: When reading in JSON, the + signs in ImageData are converted to spaces, so URL encode them!!!
        sampleWebMapJSON = sampleWebMapJSON.Replace("+", "%2b");

        string lowerSampleWebMapJSON = sampleWebMapJSON.ToLower();
        //"timeSlider":{"properties":{"startTime":1378987200000,"endTime":1379246400000,"thumbCount":2,"thumbMovingRate":2000,"timeStopInterval":{"interval":59,"units":"esriTimeUnitsMinutes"}}}
        //replace scenario_id, starttime, endtime
        //":{"startTime":1362096000000,"endTime":1362272460973,"thumbCount":2
        //objective:find beginning index of "startTime":
        int idxStartTime = sampleWebMapJSON.ToLower().IndexOf("\"starttime");
        if (idxStartTime < 0)
        {
            throw new Exception("startTime not found in web map");
        }
        //objective:find beginning index of ,"thumbcount
        int idxThumbCount = sampleWebMapJSON.ToLower().IndexOf(",\"thumbcount");
        if (idxThumbCount < 0)
        {
            throw new Exception("thumbCount not found in web map");
        }
        string sampleTimeRange = sampleWebMapJSON.Substring(idxStartTime, idxThumbCount - idxStartTime);

        //convert seconds to milliseconds
        string newTimeRange = string.Format("\"startTime\":{0},\"endTime\":{1}", startTime + "000", endTime + "000");

        string newWebMapJSON = sampleWebMapJSON.Replace(sampleTimeRange, newTimeRange);

        //REPLACE SCENARIO ID
        string newScenarioIDExpression = string.Format("SCENARIO_ID = '{0}'", scenarioID);
        newWebMapJSON = newWebMapJSON.Replace(scenarioIDExpression, newScenarioIDExpression);

        //REPLACE MAPSERVICE URL
        if (publishMode.Equals("ags"))
        {
            newWebMapJSON = newWebMapJSON.Replace(urlSampleMapService, urlAGOProxyMapService);
        }

        //REPLACE time stuff (now hardcoded to 59 minutes; replace with interval parameter)
        newWebMapJSON = newWebMapJSON.Replace("\"thumbCount\":2,\"thumbMovingRate\":2000,\"timeStopInterval\":{\"interval\":1,\"units\":\"esriTimeUnitsHours\"", "\"thumbCount\":2,\"thumbMovingRate\":2000,\"timeStopInterval\":{\"interval\":59,\"units\":\"esriTimeUnitsMinutes\"");

        //_log.DebugFormat("NEW TIME RANGE FROM SAMPLE WEB MAP IS {0}", newTimeRange);

        _log.Debug(newWebMapJSON);

        //ADD ITEM TO PORTAL
        /*
            item=asatest123_1382841944789&
            title=ASATEST123&
            tags=OilMap&
            snippet=ASATEST123&
            description=&
            accessInformation=&
            licenseInfo=&
            extent=52.6442%2C24.3836%2C54.2537%2C24.8294&
            text=%7B%22operationalLayers%22%3A%5B%7B%22url%22%3A%22https%3A%2F%2Fenergyportal.esri.com%2Farcgis%2Frest%2Fservices%2FASA_Sample%2FMapServer%22%2C%22id%22%3A%22ASA_Sample_8701%22%2C%22visibility%22%3Atrue%2C%22opacity%22%3A1%2C%22title%22%3A%22ASA_Sample%22%7D%5D%2C%22baseMap%22%3A%7B%22baseMapLayers%22%3A%5B%7B%22id%22%3A%22defaultBasemap%22%2C%22opacity%22%3A1%2C%22visibility%22%3Atrue%2C%22url%22%3A%22http%3A%2F%2Fservices.arcgisonline.com%2FArcGIS%2Frest%2Fservices%2FWorld_Topo_Map%2FMapServer%22%7D%5D%2C%22title%22%3A%22Topographic%22%7D%2C%22widgets%22%3A%7B%22timeSlider%22%3A%7B%22properties%22%3A%7B%22startTime%22%3A1362096000000%2C%22endTime%22%3A1362272461000%2C%22thumbCount%22%3A2%2C%22thumbMovingRate%22%3A2000%2C%22timeStopInterval%22%3A%7B%22interval%22%3A5%2C%22units%22%3A%22esriTimeUnitsHours%22%7D%7D%7D%7D%2C%22version%22%3A%221.9%22%7D&
            type=Web%20Map&
            typeKeywords=Web%20Map%2C%20Explorer%20Web%20Map%2C%20Map%2C%20Online%20Map%2C%20ArcGIS%20Online&
            overwrite=false&
            thumbnailURL=http%3A%2F%2Futility2.arcgisonline.com%2Farcgis%2Frest%2Fdirectories%2Farcgisoutput%2FUtilities%2FPrintingTools_GPServer%2F_ags_5d299393ccb2471e989f56f2988532ff.png&
            f=json&
            token=3X7GNqtInao_hp-KVmqozsHmhXF9pY-72S5A1qihZJyUwuS3jDCfAtgYxJ6cI1jwrtHFe-zvl2weEDsv3H3e2dkgG1gP3NQkug8cejyz4aD3P2ulO1mPEcAejPD5mBt9xlByM0_7PVuBDOkJt9lWbKuVWE2ayZTkFkrSzz5KzT2MqrlD3cUCoXmt28Q5_v4_
        */

        //item
        string postData = string.Format("item=OilMap_{0}", System.Guid.NewGuid().ToString());

        //title
        postData += string.Format("&title={0}", title);

        //tags (TODO: get tags from client)
        postData += "&tags=OilMap";

        //snippet (TODO: get snippet from client)
        postData += string.Format("&snippet={0}", title);

        //extent
        if (!(string.IsNullOrEmpty(extent)))
        {
            postData += string.Format("&extent={0}", extent);
        }

        //text
        postData += string.Format("&text={0}", newWebMapJSON);

        //type
        postData += "&type=Web Map";

        //typeKeywords
        postData += "&typeKeywords=Web Map, Map, ArcGIS Online";

        //thumbnailURL
        postData += string.Format("&thumbnailURL={0}", imgWebMapThumbnail);

        //format
        postData += "&f=json";

        //token
        postData += string.Format("&token={0}", token);

        return DoPostForString(urlAGOAddItemUser, postData);

    }


    public static string ShareItem(
        string username,
        string itemID,
        string everyone,
        string org,
        string groups,
        string tokenIn
        )
    {
        string token = tokenIn;
        if (String.IsNullOrEmpty(token))
        {
            //IF NO AGOTOKEN SENT IN, CREATE ONE
            token = GetAGOToken();
            if (string.IsNullOrEmpty(token))
            {
                throw new WebException("No AGO token available; Tried to generate token but failed.", WebExceptionStatus.TrustFailure);
            }
        }

        //https://www.arcgis.com/sharing/rest/content/users/jsmith/items/b512083cd1b64e2da1d3f66dbb135956/share
        //everyone=false
        //org=true
        //groups=4774c1c2b79046f285b2e86e5a20319e,cc5f73ab367544d6b954d82cc9c6dab7
        string urlAGOShareItem2 = string.Format(urlAGOShareItem, username, itemID);

        //everyone
        string postData = string.Format("everyone={0}", everyone);

        //org
        postData += string.Format("&org={0}", org);

        //groups
        if (!(string.IsNullOrEmpty(groups)))
        {
            postData += string.Format("&groups={0}", groups);
        }

        //format
        postData += "&f=json";

        //token
        postData += string.Format("&token={0}", token);

        return DoPostForString(urlAGOShareItem2, postData);
    }

    #region AGS Token

    public static String GetAGSToken()
    {
        //testing
        string myToken = HttpRuntime.Cache["AGS_Token"] as string;
        if (string.IsNullOrEmpty(myToken))
        {
            myToken = GenerateAGSToken();
        }

        return myToken;
    }

    public static void ReportRemovedAGSTokenCallback(String key, object value,
        System.Web.Caching.CacheItemRemovedReason removedReason)
    {
        GenerateAGSToken();
    }

    public static string GenerateAGSToken()
    {
        //http://resources.arcgis.com/en/help/arcgis-rest-api/index.html#/Generate_Token/02r3000000ts000000/
        //expiration=524160 (364 days)
        string postData = string.Format("f=json&username={0}&password={1}&client=requestip&expiration=524160", agsUser, agsPassword);

        string agsTokenData = DoPostForString(agsTokenService, postData);
        //{"token":"C4_fVBfIE8ULhZXrMuvFkwJ-i-u2E-XozErt8fhOqfy-3SHpeeoQStBDQN_NNtH4","expires":1382387566490}

        JavaScriptSerializer js = new JavaScriptSerializer();

        //Token oAuth2Token = js.Deserialize<Token>(responseData);
        Token agsToken = js.Deserialize<Token>(agsTokenData);

        //set cache item to expire 2 minutes before token expiration (usually 2 hours)
        //expiration=524160 (364 days)
        HttpRuntime.Cache.Insert(
            "AGS_Token",
            agsToken.token,
            null,
            Cache.NoAbsoluteExpiration,
            new TimeSpan(363, 23, 58, 0),
            CacheItemPriority.Default,
            new CacheItemRemovedCallback(ReportRemovedAGSTokenCallback));

        _log.InfoFormat("Retrieved new AGS token {0}", agsToken.token);

        return agsToken.token;

        /*
        //set cache item to expire 2 minutes before token expiration (usually 2 hours)
        HttpRuntime.Cache.Insert(
            "AGS_Token",
            oAuth2Token.access_token,
            null,
            Cache.NoAbsoluteExpiration,
            new TimeSpan(0, 0, oAuth2Token.expires_in - 120),
            CacheItemPriority.Default,
            new CacheItemRemovedCallback(ReportRemovedCallback));

        _log.InfoFormat("Retrieved new OAUTH2 token {0} expiring in {1} seconds", oAuth2Token.access_token, oAuth2Token.expires_in.ToString());

        return oAuth2Token.access_token;
         
         */
    }

    #endregion

    #region AGO Token
    public static String GetAGOToken()
    {
        //testing
        string myToken = HttpRuntime.Cache["AGO_Token"] as string;
        if (string.IsNullOrEmpty(myToken))
        {
            myToken = GenerateAGOToken();
        }

        return myToken;
    }

    public static void ReportRemovedAGOTokenCallback(String key, object value,
        System.Web.Caching.CacheItemRemovedReason removedReason)
    {
        GenerateAGOToken();
    }

    public static string GenerateAGOToken()
    {
        //http://resources.arcgis.com/en/help/arcgis-rest-api/index.html#/Generate_Token/02r3000000ts000000/
        string postData = string.Format("username={0}&password={1}&referer=https://www.arcgis.com&expiration=1440", agoUser, agoPassword);

        string agoTokenData = DoPostForString(agoTokenService, postData);

        if (agoTokenData.ToLower().Contains("error"))
        {
            _log.ErrorFormat("Error Retrieving Token: POSTDATA: {0} / RESPONSEDATA: {1}", postData, agoTokenData);
            return "";
        }

        JavaScriptSerializer js = new JavaScriptSerializer();

        Token agoToken = js.Deserialize<Token>(agoTokenData);

        //set cache item to expire 2 minutes before token expiration (usually 2 hours)
        HttpRuntime.Cache.Insert(
            "AGO_Token",
            agoToken.token,
            null,
            Cache.NoAbsoluteExpiration,
            new TimeSpan(23, 58, 0),
            CacheItemPriority.Default,
            new CacheItemRemovedCallback(ReportRemovedAGOTokenCallback));

        _log.InfoFormat("Retrieved new AGO token {0}", agoToken.token);

        return agoToken.token;
    }
    #endregion

    public static string DoPostForString(string url, string postData)
    {
        // create the POST request
        HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
        webRequest.Method = "POST";
        webRequest.ContentType = "application/x-www-form-urlencoded";
        webRequest.ContentLength = postData.Length;

        // POST the data
        using (StreamWriter requestWriter2 = new StreamWriter(webRequest.GetRequestStream()))
        {
            requestWriter2.Write(postData);
        }

        //  This actually does the request and gets the response back
        HttpWebResponse resp = (HttpWebResponse)webRequest.GetResponse();

        string responseData = string.Empty;

        using (StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream()))
        {
            // dumps the HTML from the response into a string variable
            responseData = responseReader.ReadToEnd();
        }

        if (responseData.ToLower().Contains("\"error\":"))
        {
            _log.ErrorFormat("ERROR in POST TO URL: {0}; POSTDATA: {1} / RESPONSEDATA: {2}", url, postData, responseData);
        }

        return responseData;

        //HttpWebRequest req = WebRequest.Create(url) as HttpWebRequest;

        //// Set the 'Method' property of the 'Webrequest' to 'POST'.
        //req.Method = "POST";

        //ASCIIEncoding encoding = new ASCIIEncoding ();
        //byte[] bytes = encoding.GetBytes(content);

        //// Set the content type of the data being posted.
        //req.ContentType = "application/x-www-form-urlencoded";

        //// Set the content length of the string being posted.
        //req.ContentLength = bytes.Length;

        //using (Stream outputStream = req.GetRequestStream())
        //{
        //    outputStream.Write(bytes, 0, bytes.Length);
        //    outputStream.Close();
        //}

        //// Send the request to the server
        //System.Net.WebResponse serverResponse = null;
        //try
        //{
        //    serverResponse = req.GetResponse();            
        //}
        //catch (WebException webExc)
        //{
        //    return webExc.Response.ToString();
        //}

        //// Set up the response to the client
        //if (serverResponse != null)
        //{
        //    response.ContentType = serverResponse.ContentType;
        //    using (Stream byteStream = serverResponse.GetResponseStream())
        //    {

        //        // Text response
        //        if (serverResponse.ContentType.Contains("text"))
        //        {
        //            using (StreamReader sr = new StreamReader(byteStream))
        //            {
        //                //{"error":{"code":498,"message":"Invalid token.","details":[]}}
        //                //{"error":{"code":400,"messageCode":"CONT_0001","message":"Item '26de091170304e3abda4115ed7ae1676' does not exist or is inaccessible.","details":[]}}
        //                string strResponse = sr.ReadToEnd();

        //                //_log.Debug(strResponse);

        //                if (strResponse.Contains("{\"error\":{\"code\":498"))
        //                {
        //                    _log.Error("Encountered invalid token");
        //                    throw new WebException("Invalid Token");
        //                }
        //                response.Write(strResponse);
        //            }
        //        }
        //        else
        //        {
        //            _log.Debug("non-text-resource of length " + serverResponse.ContentLength.ToString());

        //            // Binary response (image, lyr file, other binary file)
        //            BinaryReader br = new BinaryReader(byteStream);
        //            byte[] outb = br.ReadBytes((int)serverResponse.ContentLength);
        //            br.Close();

        //            // Tell client not to cache the image since it's dynamic
        //            response.CacheControl = "no-cache";

        //            // Send the image to the client
        //            // (Note: if large images/files sent, could modify this to send in chunks)
        //            response.OutputStream.Write(outb, 0, outb.Length);
        //        }

        //        serverResponse.Close();
        //    }
        //}
    }

    public static string LogExceptionReturnJSON(int code, string message, string details)
    {
        _log.Error("Error Occurred: " + message + " Stack trace: " + details);
        return "{\"error\":{\"code\":" + code + ",\"message\":\"" + message + "\",\"details\":[\"" + details + "\"]}}";
    }
}

[Serializable]
public class Token
{
    //response {"token" : "ShBh03DRIR1e1RbiNmoB-YfqPdMH31bKWY9BxlL5RcrSLRZTFhLw9RSGjbLE-faz-c2xxvq21-lSdSAobxRfEQdOcxAVbmJbm20O_GZHDuLnlJvXMSuOKuj7I23sa45M68Gi51ggAChdyjJgtOAsmg..","expires" : 1367777161054,"ssl" : false}
    public string token { get; set; }
    public long expires { get; set; }
}

[Serializable]
public class Token1
{
    public string access_token { get; set; }
    public int expires_in { get; set; }
}

[Serializable]
public class oAuth2Error
{
    public int code { get; set; }
    public string message { get; set; }
    public string messageCode { get; set; }
    public string details { get; set; }

    //{"error":{"code":498,"message":"Invalid token.","details":[]}}
    //{"error":{"code":400,"messageCode":"CONT_0001","message":"Item '26de091170304e3abda4115ed7ae1676' does not exist or is inaccessible.","details":[]}}
}
