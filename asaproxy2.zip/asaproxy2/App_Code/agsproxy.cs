﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Net;
using System.Web.Caching;
using System.Web.Script.Serialization;
using System.Configuration;

/// <summary>
/// Summary description for oauth2proxy
/// </summary>
public class agsproxy : IHttpHandler
{
    private HttpContext context = null;
    private HttpRequest request = null;
    private static readonly log4net.ILog _log = log4net.LogManager.GetLogger("agsProxy");
    private static readonly log4net.ILog _logReferer = log4net.LogManager.GetLogger("agsProxyReferer");
    private string uri = "";

    public agsproxy()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    #region IHttpHandler Members

    public bool IsReusable
    {
        get
        {
            return false;
        }
    }

    public void ProcessRequest(HttpContext _context)
    {
        context = _context;
        request = context.Request;

        // Get the URL requested by the client (take the entire querystring at once
        //  to handle the case of the URL itself containing querystring parameters)
        uri = Uri.UnescapeDataString(context.Request.QueryString.ToString());

        string referer = context.Request.Headers["Referer"];
        _logReferer.DebugFormat("REFERER: {0} : REQUEST: {1}", referer, uri);

        try
        {
            string operation = request.QueryString["operation"];
            string strResponse = "";

            if (string.IsNullOrEmpty(operation))
            {
                throw new WebException("No operation parameter found");
            }
            switch (operation)
            {
                case "InsertFeatures":
                    string layerID = request.Form["layerID"];
                    if (string.IsNullOrEmpty(layerID))
                    {
                        throw new WebException("No layerId found in POST");
                    }
                    string features = request.Form["features"];
                    if (string.IsNullOrEmpty(features))
                    {
                        throw new WebException("No features found in POST");
                    }
                    string token = "";
                    //token is expected only if inserting to hosted feature service
                    if (!(string.IsNullOrEmpty(request.Form["token"])))
                    {
                        token = request.Form["token"];
                    }

                    _log.DebugFormat("OPERATION: {0} ; LAYERID: {1} ; FEATUREJSON: {2} ; AGOTOKEN: {3}", operation, layerID, features, token);

                    strResponse = asaHelper.InsertFeatures(layerID, features, token);

                    break;

                case "CreateWebMap":
                    /*
                    string username,
                    string scenarioID, 
                    string title, 
                    string startTime, 
                    string endTime, 
                    string token, 
                    string extent
                     */
                    string username = request.Form["username"];
                    if (string.IsNullOrEmpty(username))
                    {
                        throw new WebException("No username found in POST");
                    }
                    string scenarioID = request.Form["scenarioID"];
                    if (string.IsNullOrEmpty(scenarioID))
                    {
                        throw new WebException("No scenarioID found in POST");
                    }
                    string title = request.Form["title"];
                    if (string.IsNullOrEmpty(title))
                    {
                        throw new WebException("No title found in POST");
                    }
                    string startTime = request.Form["startTime"];
                    if (string.IsNullOrEmpty(startTime))
                    {
                        throw new WebException("No startTime found in POST");
                    }
                    string endTime = request.Form["endTime"];
                    if (string.IsNullOrEmpty(endTime))
                    {
                        throw new WebException("No endTime found in POST");
                    }
                    string extent = request.Form["extent"];
                    if (string.IsNullOrEmpty(extent))
                    {
                        //throw new WebException("No extent found in POST");
                    }
                    token = "";
                    if (!(string.IsNullOrEmpty(request.Form["token"])))
                    {
                        token = request.Form["token"];
                    }
                    _log.DebugFormat("username: {0} ; scenarioID: {1} ; title: {2} ; startTime: {3} ; endTime: {4} ; extent: {5} ; token: {6}",
                        username, scenarioID, title, startTime, endTime, extent, token);

                    strResponse = asaHelper.CreateWebMap(username, scenarioID, title, startTime, endTime, extent, token);

                    break;

                case "ShareItem":
                    /*
                    string username,
                    string itemID,
                    string everyone,
                    string org,
                    string groups
                     */
                    username = request.Form["username"];
                    if (string.IsNullOrEmpty(username))
                    {
                        throw new WebException("No username found in POST");
                    }
                    string itemID = request.Form["itemID"];
                    if (string.IsNullOrEmpty(itemID))
                    {
                        throw new WebException("No itemID found in POST");
                    }
                    string everyone = request.Form["everyone"];
                    if (string.IsNullOrEmpty(everyone))
                    {
                        throw new WebException("No everyone found in POST");
                    }
                    string org = request.Form["org"];
                    if (string.IsNullOrEmpty(org))
                    {
                        throw new WebException("No org found in POST");
                    }
                    string groups = request.Form["groups"];
                    if (string.IsNullOrEmpty(groups))
                    {
                        //user chooses not to share... ok
                        //throw new WebException("No groups found in POST");
                    }
                    token = request.Form["token"];
                    if (string.IsNullOrEmpty(token))
                    {
                        throw new WebException("No token found in POST");
                    }
                    _log.DebugFormat("username: {0} ; itemID: {1} ; everyone: {2} ; org: {3} ; groups: {4} ; token: {5}",
                        username, itemID, everyone, org, groups, token);

                    strResponse = asaHelper.ShareItem(username, itemID, everyone, org, groups, token);

                    break;

                default:
                    break;
            }
            _log.DebugFormat("OPERATION: {0}: {1}", operation, strResponse);

            //SEND RESPONSE
            context.Response.Write(strResponse);
        }
        catch (Exception ex)
        {
            HttpResponse response = context.Response;
            response.Write(asaHelper.LogExceptionReturnJSON(500, ex.Message, ex.StackTrace));
        }
        finally
        {
            context.Response.End();
        }
    }
    #endregion

    private void ProcessWebRequest()
    {

        /*
        string uriWithToken = "";

        string token = getToken(uri, referer);
        if (!String.IsNullOrEmpty(token))
        {
            if (uri.Contains("?"))
                uri += "&token=" + token;
            else
                uri += "?token=" + token;
        }


        // Get token, if applicable, and append to the request
        if (uri.ToLower().Contains("arcgis.com/"))
        {
            //bug with jquery ago group search: uri has no ?
            //https://clancy.maps.arcgis.com/sharing/rest/search&callback=jQuery18100039362147616335275_1367711480524&q=(+group:"291b693119444d8995a363085853cf57"+(type:"Web+Map"+AND+typekeywords:"Web+Map"+NOT+(type:"Web+Mapping+Application")))&f=json&sortField=title&sortOrder=asc&num=4&v=1&_=1367711484306?token=AH7Vbd78LHp7isn4UBOM5FgIw5Kz_piM9X8JNzdFfPXS6EkY5j6LrsrsjBa0n4HuEtI-Tt1lUaQvoInXfKK2vP7FCjxUGNtbrl9gf-Nshr2riDGUfEwewlARoB8XQJ-fTtba6He2ujvVk_UaLaSwTg..

            //if uri doesn't contain ?
            if (uri.IndexOf("?") == -1)
            {
                //FIX: convert first & into ?
                if (uri.Contains("&"))
                {
                    int ampIndex = uri.IndexOf("&");
                    uri = uri.Substring(0, ampIndex) + "?" + uri.Substring(ampIndex + 1);
                }
            }

            string token = GetAGSToken();
            if (!String.IsNullOrEmpty(token))
            {
                if (uri.Contains("?"))
                    uriWithToken = uri + "&token=" + token;
                else
                    uriWithToken = uri + "?token=" + token;
            }
        }
        else
        {
            uriWithToken = uri;
        }

        _log.Debug(uriWithToken);

        HttpResponse response = context.Response;

        System.Net.WebRequest req = System.Net.WebRequest.Create(new Uri(uriWithToken));
        req.Method = context.Request.HttpMethod;

        // Set body of request for POST requests
        if (context.Request.InputStream.Length > 0)
        {
            byte[] bytes = new byte[context.Request.InputStream.Length];
            context.Request.InputStream.Read(bytes, 0, (int)context.Request.InputStream.Length);
            req.ContentLength = bytes.Length;
            req.ContentType = "application/x-www-form-urlencoded";
            using (Stream outputStream = req.GetRequestStream())
            {
                outputStream.Write(bytes, 0, bytes.Length);
            }
        }

        // Send the request to the server
        System.Net.WebResponse serverResponse = null;
        try
        {
            serverResponse = req.GetResponse();
        }
        catch (WebException webExc)
        {
            response.StatusCode = 500;
            response.StatusDescription = webExc.Status.ToString();
            response.Write(webExc.Response);
            response.End();
            return;
        }

        // Set up the response to the client
        if (serverResponse != null)
        {
            response.ContentType = serverResponse.ContentType;
            using (Stream byteStream = serverResponse.GetResponseStream())
            {

                // Text response
                if (serverResponse.ContentType.Contains("text"))
                {
                    using (StreamReader sr = new StreamReader(byteStream))
                    {
                        //{"error":{"code":498,"message":"Invalid token.","details":[]}}
                        //{"error":{"code":400,"messageCode":"CONT_0001","message":"Item '26de091170304e3abda4115ed7ae1676' does not exist or is inaccessible.","details":[]}}
                        string strResponse = sr.ReadToEnd();

                        //_log.Debug(strResponse);

                        if (strResponse.Contains("{\"error\":{\"code\":498"))
                        {
                            _log.Error("Encountered invalid token");
                            throw new WebException("Invalid Token", WebExceptionStatus.TrustFailure);
                        }
                        response.Write(strResponse);
                    }
                }
                else
                {
                    _log.Debug("non-text-resource of length " + serverResponse.ContentLength.ToString());

                    // Binary response (image, lyr file, other binary file)
                    BinaryReader br = new BinaryReader(byteStream);
                    byte[] outb = br.ReadBytes((int)serverResponse.ContentLength);
                    br.Close();

                    // Tell client not to cache the image since it's dynamic
                    response.CacheControl = "no-cache";

                    // Send the image to the client
                    // (Note: if large images/files sent, could modify this to send in chunks)
                    response.OutputStream.Write(outb, 0, outb.Length);
                }

                serverResponse.Close();
            }
        }
        response.End();
        */
    }


    /*
     {
       "access_token":"2YotnFZFEjr1zCsicMWpAA",
       "token_type":"example",
       "expires_in":7200, (seconds)
       "refresh_token":"tGzv3JOkF0XG5Qx2TlKWIA",
       "example_parameter":"example_value"
     }
     */

}


