from pystoch.readers.oilmdl_om_reader import OilModelDirectAccessOMReader as OMDAR


reader = OMDAR('C:\OILMAPAV10\Loc_Data\GBR\OUTDATA\GBR_OIL6')




