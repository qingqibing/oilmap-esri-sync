import log

from parallel import *



log.set_logging(mpi_rank, mpi_size)