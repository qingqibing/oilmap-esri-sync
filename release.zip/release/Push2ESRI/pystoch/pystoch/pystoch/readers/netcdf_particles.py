#!/usr/bin/env python
'''
@author David Stuebe <dstuebe@asasscience.com>
@file netcdf_particles.py
@date 03/11/13
@description A reader class for getting data from netcdf files
'''


class NetcdfParticleReader(AbstractParticleReader):
	pass