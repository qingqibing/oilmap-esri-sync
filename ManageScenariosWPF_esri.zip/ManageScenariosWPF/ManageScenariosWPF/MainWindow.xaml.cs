﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using ESRI.ArcGIS.Client;
using ESRI.ArcGIS.Client.Geometry;
using ESRI.ArcGIS.Client.Tasks;
using System.Net;
using System.IO;
using System;
using System.ComponentModel;
using System.Collections.Generic;


namespace ManageScenariosWPF
{
    public partial class MainWindow : UserControl
    {
        private Graphic _lastGraphic;
        private static ESRI.ArcGIS.Client.Projection.WebMercator _mercator =
                new ESRI.ArcGIS.Client.Projection.WebMercator();

        private BackgroundWorker backgroundWorker1;

        public MainWindow()
        {
            InitializeComponent();
            InitializeBackgroundWorker();

            //ESRI.ArcGIS.Client.Geometry.Envelope initialExtent =
            //                    new ESRI.ArcGIS.Client.Geometry.Envelope(
            //            _mercator.FromGeographic(
            //                    new ESRI.ArcGIS.Client.Geometry.MapPoint(-122.4545596, 37.783443296)) as MapPoint,
            //            _mercator.FromGeographic(
            //                    new ESRI.ArcGIS.Client.Geometry.MapPoint(-122.4449924, 37.786447331)) as MapPoint);

            //initialExtent.SpatialReference = new SpatialReference(3857);

            //MyMap.Extent = initialExtent;
        }

        // Set up the BackgroundWorker object by  
        // attaching event handlers.  
        private void InitializeBackgroundWorker()
        {
            backgroundWorker1 = new BackgroundWorker();
            backgroundWorker1.WorkerReportsProgress = true;
            backgroundWorker1.WorkerSupportsCancellation = true;

            backgroundWorker1.DoWork += new DoWorkEventHandler(backgroundWorker1_DoWork);
            backgroundWorker1.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorker1_RunWorkerCompleted);
            backgroundWorker1.ProgressChanged += new ProgressChangedEventHandler(backgroundWorker1_ProgressChanged);
        }


        private void FeatureLayer_MouseLeftButtonUp(object sender, GraphicMouseButtonEventArgs e)
        {
            if (_lastGraphic != null)
                _lastGraphic.UnSelect();

            e.Graphic.Select();
            if (e.Graphic.Selected)
                MyDataGrid.ScrollIntoView(e.Graphic, null);

            _lastGraphic = e.Graphic;
        }

        private void MyMap_Loaded(object sender, RoutedEventArgs e)
        {
            MyDataGrid.Map = MyMap;
            MyDataGrid.GraphicsLayer = MyMap.Layers[1] as ESRI.ArcGIS.Client.GraphicsLayer;
        }

        private void DeleteScenarioButton_Click(object sender, RoutedEventArgs e)
        {
            ClearStatus();

            if (MyDataGrid.SelectedGraphics.Count < 1)
            {
                UpdateStatus("No scenarios selected.");
                return;
            }

            DeleteScenarioButton.IsEnabled = false;
            backgroundWorker1.RunWorkerAsync(MyDataGrid.SelectedGraphics);
        }

        private void UpdateStatus(string text)
        {
            ResponseTextBlock.Text = (text + "\n" + ResponseTextBlock.Text);
        }

        private void ClearStatus()
        {
            ResponseTextBlock.Text = "";
        }


        // Worker Method 
        void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker worker = sender as BackgroundWorker;
            if (worker.CancellationPending == true)
            {
                e.Cancel = true;
                return;
            }

            //get the graphics from calling thread
            IList<Graphic> trajectories = e.Argument as IList<Graphic>;

            string[] layerNames = { "Trajectory", "Particles", "Thickness", "Currents", "Winds" };
            int i = 0;
            int batchSize = 500;

            foreach (var trajectory in trajectories)
            {
                i++;
                if (trajectory.Attributes["SCENARIO_ID"] == null)
                {
                    worker.ReportProgress(0, "no SCENARIO_ID found in trajectory " + i);
                    continue;
                }
                if (string.IsNullOrEmpty(trajectory.Attributes["SCENARIO_ID"].ToString()))
                {
                    worker.ReportProgress(0, "SCENARIO_ID in trajectory " + i + " is empty");
                    continue;
                }

                string scenario = trajectory.Attributes["SCENARIO_ID"].ToString();
                string strWhere = string.Format("SCENARIO_ID='{0}'", scenario);
                //string scenario = "OILSPILL_test_";
                //string strWhere = "SCENARIO_ID like 'OILSPILL_test_%'";
                
                //string postData = string.Format("where={0}", WebUtility.UrlEncode(strWhere));

                //process each layer
                for (int layerId = 4; layerId >= 0; layerId--)
                {
                    string noFeaturesAlert = string.Format("No features found in {0}: {1}", scenario, layerNames[layerId]);

                    //get oids
                    FeatureSet featureSet = GetFeatureIds(layerId, strWhere);

                    if (featureSet == null || featureSet.ObjectIDs == null)
                    {
                        worker.ReportProgress(0, noFeaturesAlert);
                        continue;
                    }

                    //split set of oids into sets of comma-delimited up to batch size
                    string delimIds = "";
                    int fCount = 0;
                    foreach (int objectId in featureSet.ObjectIDs)
                    {
                        fCount++;
                        //add batch delimiter
                        string sep = fCount % batchSize == 0 ? ";" : ",";
                        delimIds += objectId + sep;
                    }
                    if (fCount < 1)
                    {
                        worker.ReportProgress(0, noFeaturesAlert);
                        continue;
                    }

                    //truncate last separator
                    delimIds = delimIds.Substring(0, delimIds.Length - 1);
                    string[] aryDelimIds = delimIds.Split(";".ToCharArray());

                    string layerUrl = string.Format("{0}/{1}/deleteFeatures?f=json", Properties.Settings.Default.UrlFeatureService, layerId);

                    foreach (string ids in aryDelimIds)
                    {
                        //batch delete
                        string postDataOIDs = string.Format("objectIds={0}", WebUtility.UrlEncode(ids));
                        try
                        {
                            this.DoPostForString(layerUrl, postDataOIDs);
                        }
                        catch (Exception ex)
                        {
                            worker.ReportProgress(0, ex.Message);
                            e.Cancel = true;
                            return;
                        }

                        //update feature count after delete
                        FeatureSet featureSet2 = GetFeatureIds(layerId, strWhere);
                        int fCount2 = 0;
                        foreach (int objectId2 in featureSet2.ObjectIDs)
                        {
                            fCount2++;
                        }
                        string updateText2 = string.Format("{0}: {1}: remaining: {2}", scenario, layerNames[layerId], fCount2);
                        worker.ReportProgress(0, updateText2);
                    }
                }
            }

        }

        // This event handler updates the progress bar. 
        private void backgroundWorker1_ProgressChanged(object sender,
            ProgressChangedEventArgs e)
        {
            UpdateStatus((string)e.UserState);
            //UpdateStatus(e.ProgressPercentage);
        }

        // Completed Method 
        void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled) 
            { 
                UpdateStatus("Cancelled"); 
            } 
            else if (e.Error != null)
            { 
                UpdateStatus("Exception Thrown"); 
            } 
            else 
            {
                UpdateStatus("Completed");
            }
            DeleteScenarioButton.IsEnabled = true;
        }

        private string DoPostForString(string url, string postData)
        {
            // create the POST request
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
            webRequest.Method = "POST";
            webRequest.ContentType = "application/x-www-form-urlencoded";
            webRequest.ContentLength = postData.Length;
            webRequest.Timeout = 1000*60*5;

            // POST the data
            using (StreamWriter requestWriter2 = new StreamWriter(webRequest.GetRequestStream()))
            {
                requestWriter2.Write(postData);
            }

            //  This actually does the request and gets the response back
            HttpWebResponse resp = (HttpWebResponse)webRequest.GetResponse();

            string responseData = string.Empty;

            using (StreamReader responseReader = new StreamReader(webRequest.GetResponse().GetResponseStream()))
            {
                // dumps the HTML from the response into a string variable
                responseData = responseReader.ReadToEnd();
            }

            if (responseData.ToLower().Contains("\"error\":"))
            {
                return(string.Format("ERROR in POST TO URL: {0}; POSTDATA: {1} / RESPONSEDATA: {2}", url, postData, responseData));
            }
            return responseData;
        }

        private FeatureSet GetFeatureIds(int layerId, string where)
        {
            Query query = new Query()
            {
                ReturnGeometry = false,
                ReturnIdsOnly = true,
                Where = where
            };
            QueryTask queryTask = new QueryTask()
            {
                Url = string.Format("{0}/{1}", Properties.Settings.Default.UrlFeatureService, layerId)
            };
            return queryTask.Execute(query);
        }
    }

}
