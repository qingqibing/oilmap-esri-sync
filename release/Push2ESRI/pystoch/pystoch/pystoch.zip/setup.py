try:
    from setuptools import setup, find_packages
    packages = find_packages()
except ImportError:
    from distutils import setup
    packages = ['pystoch','pystoch/trajectory_data']

setup(
    name='pystoch',
    version='0.1',
    description='Python implementation of stochastic lagrangian oil probablility analysis',
    author='David Stuebe',
    author_email='DStuebe@ASAScience.com',
    url='http://192.168.100.14/Commercial/pystoch.git',
    classifiers=[
        'License :: ASA Interal',
        'Topic :: Oil Model :: Stochastic',
        'Topic :: Grid:: Probability',
        ],
    license='ASA Internal',
    keywords='oil model probability grid',
    packages=packages,
    package_data={'':['trajectory_data']},
    install_requires = [
            'netCDF4>=1.0.0',
            'nose>=1.2.0',
            'numexpr>=2.0.0',
            'Cython>=0.17',
            'numpy>=1.7.0',
            'pyaml>=13.05.2'
            ],
)
